-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2017 at 11:54 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `midexam`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `content` varchar(250) NOT NULL,
  `true_or_false` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`id`, `quiz_id`, `content`, `true_or_false`) VALUES
(1, 1, 'I don''t know.....', 0),
(2, 1, 'Barack Obama', 0),
(3, 1, 'Someone in the world.....', 0),
(4, 1, 'George Washington.....', 1),
(5, 7, '3', 1),
(7, 9, '2', 1),
(8, 7, '1', 0),
(9, 10, 'I don''t know', 0),
(10, 10, '40', 1),
(11, 9, '3', 0),
(12, 12, 'Rajendra-I', 0),
(13, 12, 'Rajaraja-II', 0),
(14, 12, 'Kulottunga-I ', 1),
(15, 12, 'Kulottunga-II', 0),
(16, 11, 'Tran Quoc Toan', 1),
(17, 11, 'Someone', 0),
(18, 13, 'Mughals', 0),
(19, 13, 'Marathas', 1),
(20, 13, 'Rajputs', 0),
(23, 13, 'Sikhs', 0),
(24, 15, 'Akbar ', 0),
(25, 15, 'Babur ', 1),
(26, 15, 'Ibrahim Lodhi', 0),
(27, 15, 'Sher Shah Suri', 0),
(28, 16, 'Malabar', 1),
(29, 16, 'Kanara', 0),
(30, 16, 'Travancore', 0),
(31, 16, 'Tanjore', 0),
(32, 17, 'Tharu', 1),
(33, 17, 'Boxa', 0),
(34, 17, 'Jaad', 0),
(35, 17, 'Bhotia', 0),
(36, 18, 'Pali', 1),
(37, 18, 'Prakrit', 0),
(38, 18, 'Sanskrit', 0),
(39, 18, 'Armike', 0),
(40, 19, 'Mughal period', 1),
(41, 19, 'Gorkha period', 0),
(42, 19, 'Dogra period', 0),
(43, 19, 'British period', 0),
(44, 20, 'Kumaoni', 0),
(45, 20, 'Garhwali', 0),
(46, 20, 'Sanskrit', 1),
(47, 20, 'Prakrit', 0),
(48, 21, 'Chamoli district', 0),
(49, 21, 'Nainital district', 0),
(50, 21, 'Haridwar district ', 0),
(51, 21, 'Almora district', 1),
(52, 22, 'Landlords', 0),
(53, 22, 'Former kings', 1),
(54, 22, 'Industrialists', 0),
(55, 22, 'Indio planters', 0),
(56, 23, '74 mins', 1),
(57, 23, '90 mins', 0),
(58, 23, '56 mins', 0),
(59, 23, '60 mins', 0),
(60, 24, 'First ', 0),
(61, 24, 'Second', 1),
(62, 24, 'Third', 0),
(63, 24, 'Fourth', 0),
(64, 25, 'Mouse ', 0),
(65, 25, 'Light pen', 0),
(66, 25, 'Keyboard', 0),
(67, 25, 'VDU', 1),
(68, 26, 'Arithmetic Long Unit ', 0),
(69, 26, 'All Longer Units ', 0),
(70, 26, 'Around Logical Units', 0),
(71, 26, 'Arithmetic and Logical Units ', 1),
(72, 27, 'Compression', 1),
(73, 27, 'Fragmentation', 0),
(74, 27, 'Encapsulation', 0),
(75, 27, 'None of the above ', 0),
(76, 28, 'DVD', 0),
(77, 28, 'Hard Disk ', 0),
(78, 28, 'Microprocessor', 1),
(79, 28, 'Mouse', 0),
(80, 29, 'Operating System ', 0),
(81, 29, 'Compiler', 0),
(82, 29, 'DBMS ', 1),
(83, 29, 'None of the above', 0),
(84, 30, 'Super-micro', 0),
(85, 30, 'Super Computer', 1),
(86, 30, 'Micro Computer', 0),
(87, 30, 'Mini Computer', 0),
(88, 31, 'Cache memory', 0),
(89, 31, 'RAM', 0),
(90, 31, 'ROM', 1),
(91, 31, 'None of the above', 0),
(92, 32, 'Abacus', 0),
(93, 32, 'Analytical Engine', 1),
(94, 32, 'Calculator', 0),
(95, 32, 'Processor', 0),
(96, 33, 'Direct database access', 0),
(97, 33, 'Sequential database access', 0),
(98, 33, 'Alternate database access', 0),
(99, 33, 'Instance database access', 1),
(100, 34, 'Monitor', 1),
(101, 34, 'Printer', 0),
(102, 34, 'Sound System', 0),
(103, 34, 'Semiconducter', 0),
(104, 35, 'Android', 1),
(105, 35, 'Excel', 0),
(106, 35, 'Powerpoint', 0),
(107, 35, 'Word', 0),
(108, 36, 'Open Access', 0),
(109, 36, 'Open Source', 1),
(110, 36, 'Windows Based', 0),
(111, 36, 'Mac Based', 0),
(112, 37, 'Code', 0),
(113, 37, 'Colour', 0),
(114, 37, 'Computer', 0),
(115, 37, 'Character', 1),
(116, 38, 'Seven', 1),
(117, 38, 'Five', 0),
(118, 38, 'Four', 0),
(119, 38, 'Six', 0),
(120, 39, 'Chart sheet', 1),
(121, 39, 'Exclusive sheet', 0),
(122, 39, 'Primary sheet', 0),
(123, 39, 'Reference sheet', 0),
(124, 40, 'make copies of documents.', 0),
(125, 40, 'save changes to documents.', 0),
(126, 40, 'delete text in documents.', 0),
(127, 40, 'format your documents.', 1),
(128, 41, 'Chart Location', 0),
(129, 41, 'Chart Style', 0),
(130, 41, 'Chart Options', 0),
(131, 41, 'Chart Source Data', 1),
(132, 42, 'Linkers', 0),
(133, 42, 'Protocol', 0),
(134, 42, 'Cable', 0),
(135, 42, 'URL', 1),
(136, 43, 'Fetching', 0),
(137, 43, 'Storing', 0),
(138, 43, 'Decoding', 0),
(139, 43, 'Executing', 1),
(140, 44, 'e-selling-n-buying', 0),
(141, 44, 'e-finance', 0),
(142, 44, 'e-commerce', 1),
(143, 44, 'e-trading', 0),
(144, 45, 'Output', 0),
(145, 45, 'Input', 1),
(146, 45, 'Throughut', 0),
(147, 45, 'Reports', 0),
(148, 46, 'Plotter', 0),
(149, 46, 'Scanner', 1),
(150, 46, 'Mouse ', 0),
(151, 46, 'Printer', 0),
(152, 47, 'input data', 0),
(153, 47, 'store data', 0),
(154, 47, 'scan data', 0),
(155, 47, 'view or print data', 1),
(156, 48, 'Printing Device', 0),
(157, 48, 'Output Device', 0),
(158, 48, 'Storage Device', 0),
(159, 48, 'Input Device', 1),
(160, 49, 'colour the document.', 0),
(161, 49, 'save the document.', 0),
(162, 49, 'copy the document.', 0),
(163, 49, 'view how the document will appear when printed.', 1),
(164, 50, 'transfer time.', 0),
(165, 50, 'movement time.', 0),
(166, 50, 'access time.', 1),
(167, 50, 'data input time.', 0),
(168, 51, 'Because its function goes back and forth every time it is pressed', 1),
(169, 51, 'Because it cannot be used for entering numbers', 0),
(170, 51, 'Because it cannot be used to delete', 0),
(171, 51, 'Because it cannot be used to insert', 0),
(172, 52, 'Blinker', 1),
(173, 52, 'Cursor', 0),
(174, 52, 'Causer', 0),
(175, 52, 'Pointer', 0);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `category_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category_name`) VALUES
(1, 'History'),
(2, 'Math'),
(3, 'Physical'),
(4, 'Biology'),
(5, 'Computer');

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `id` int(11) NOT NULL,
  `exam_name` varchar(250) NOT NULL,
  `num_of_test` int(11) NOT NULL,
  `num_of_question` int(11) NOT NULL,
  `course_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`id`, `exam_name`, `num_of_test`, `num_of_question`, `course_id`) VALUES
(1, 'Test Math Basic', 6, 10, 2),
(2, 'Exam History', 4, 20, 1),
(3, 'Exam Physical Basic', 3, 20, 3),
(4, 'Math Basic', 3, 20, 2),
(5, 'Computer Exam 1', 3, 20, 5);

-- --------------------------------------------------------

--
-- Table structure for table `exam_item`
--

CREATE TABLE `exam_item` (
  `id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_item`
--

INSERT INTO `exam_item` (`id`, `exam_id`, `quiz_id`) VALUES
(93, 1, 10),
(120, 2, 1),
(109, 2, 11),
(110, 2, 12),
(111, 2, 13),
(112, 2, 15),
(113, 2, 16),
(114, 2, 17),
(115, 2, 18),
(116, 2, 19),
(117, 2, 20),
(118, 2, 21),
(119, 2, 22),
(106, 4, 7),
(107, 4, 10),
(126, 5, 28),
(129, 5, 31),
(130, 5, 32),
(131, 5, 33),
(132, 5, 34),
(133, 5, 35),
(134, 5, 36),
(135, 5, 37),
(136, 5, 38),
(137, 5, 39),
(138, 5, 41),
(139, 5, 42),
(140, 5, 43),
(141, 5, 44),
(142, 5, 45),
(146, 5, 49),
(144, 5, 50),
(145, 5, 51),
(143, 5, 52);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `difficult` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`id`, `category_id`, `content`, `difficult`) VALUES
(1, 1, 'Who is the first president of the US?', 'Normal'),
(7, 2, '1+2+0=?', 'Easy'),
(9, 4, 'How many eyes in the face on normal human?', 'Easy'),
(10, 2, '5*8/9+9=?', 'Easy'),
(11, 1, 'Who is Tran Quoc Toan?', 'Easy'),
(12, 1, 'Name the Chola ruler who sent an embassy of 72 merchants to China in AD 1077?', 'Hard'),
(13, 1, 'Who among the following gave maximum resistance to the British?', 'Hard'),
(15, 1, 'Who among the following was the first to make use of artillery in warfare during the medieval period in India?', 'Hard'),
(16, 1, 'Which one of the following region came under the direct administration of the English East India Company after the third Anglo-Mysore war?', 'Hard'),
(17, 1, 'Which of the following tribes worship the deity ''Bhumsen''?', 'Hard'),
(18, 1, 'In which language are the ''Pandukeshwar copper plates'' written?', 'Hard'),
(19, 1, 'During which period did the Colonial conflict start in Uttarakhand ?', 'Hard'),
(20, 1, 'The court language of Katyuris was -', 'Hard'),
(21, 1, 'The Lakhu cave having ancient rock paintings is located in -', 'Hard'),
(22, 1, '''Privy Purse'' was related to whom in the Post-Independence period ?', 'Hard'),
(23, 5, 'Compact discs, (according to the original CD specifications) hold how many minutes of music?', 'Normal'),
(24, 5, 'In which generation of computers, transistors were used ?', 'Normal'),
(25, 5, 'Which of the following is not an input device ?', 'Normal'),
(26, 5, '''ALU'' stands for ?', 'Normal'),
(27, 5, 'What type of process creates a smaller file that is faster to transfer over the internet ?', 'Normal'),
(28, 5, 'The term ''Pentium'' is related to -', 'Normal'),
(29, 5, 'Which of the following is used to Manage Data Base?', 'Normal'),
(30, 5, 'Which of the following is the most powerful type computer?', 'Normal'),
(31, 5, 'Which of the following is an example of non-volatile memory?', 'Normal'),
(32, 5, 'The first mechanical computer designed by Charles Babbage was called -', 'Normal'),
(33, 5, 'Unsorted transaction that can used to immediately update database is called -', 'Normal'),
(34, 5, 'LED, LCD, CRT are the names related to different types of -', 'Normal'),
(35, 5, 'Microsoft Office does not include -', 'Normal'),
(36, 5, 'Ubuntu is which type of operating system -', 'Normal'),
(37, 5, 'In MICR, C stands for -', 'Normal'),
(38, 5, 'The OSI reference model is divided into how many layers?', 'Normal'),
(39, 5, 'When a chart is placed on this, it is much larger and there is no other data on it -', 'Normal'),
(40, 1, ' In word, you can use Styles to -', 'Normal'),
(41, 5, 'This dialog box specifies or modifies the work sheet cell range containing data to be charted -', 'Normal'),
(42, 5, 'Which of the following is used by the browser to connect to the location of the Internet resources?', 'Normal'),
(43, 5, '___is the process of carrying out commands.', 'Normal'),
(44, 5, ' The process of trading goods over the Internet is known as -', 'Normal'),
(45, 5, 'Information that comes from an external source and fed into computer software is called -', 'Normal'),
(46, 5, 'Information that comes from an external source and fed into computer software is called -', 'Normal'),
(47, 5, 'Using output devices one can -', 'Normal'),
(48, 5, 'Which of the following categories would include a keyboard?', 'Normal'),
(49, 5, 'Print Preview command is used when you want to -', 'Normal'),
(50, 5, 'The time for the actual data transfer after receiving the request for data from secondary storage is referred to as the disk''s -', 'Normal'),
(51, 5, 'Why is the Caps Lock key referred to as a toggle key?', 'Normal'),
(52, 5, 'Your position in the text is shown by a -', 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `point` int(11) NOT NULL,
  `pass_or_fail` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `user_id`, `exam_id`, `point`, `pass_or_fail`) VALUES
(60, 1, 1, 0, 'Fail'),
(61, 1, 1, 3, 'Fail'),
(62, 1, 1, 3, 'Fail'),
(63, 1, 2, 0, 'Fail'),
(64, 1, 2, 9, 'Fail'),
(65, 1, 2, 9, 'Pass'),
(66, 1, 2, 0, 'Fail'),
(67, 1, 2, 0, ''),
(68, 1, 2, 0, 'Fail'),
(69, 4, 2, 0, 'Fail');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `id` int(11) NOT NULL,
  `result_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `choice_answer` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`id`, `result_id`, `quiz_id`, `choice_answer`) VALUES
(128, 60, 7, ''),
(129, 60, 7, ''),
(130, 60, 7, ''),
(131, 60, 10, ''),
(132, 60, 10, ''),
(133, 60, 10, ''),
(134, 61, 7, '1'),
(135, 61, 7, '3'),
(136, 61, 7, '3'),
(137, 61, 10, 'I don''t know'),
(138, 61, 10, '40'),
(139, 61, 10, 'I don''t know'),
(140, 62, 7, '1'),
(141, 62, 7, '3'),
(142, 62, 7, '3'),
(143, 62, 10, 'I don''t know'),
(144, 62, 10, '40'),
(145, 62, 10, 'I don''t know'),
(146, 63, 1, ''),
(147, 63, 11, ''),
(148, 63, 12, ''),
(149, 63, 13, ''),
(150, 63, 15, ''),
(151, 63, 16, ''),
(152, 63, 17, ''),
(153, 63, 18, ''),
(154, 63, 19, ''),
(155, 63, 20, ''),
(156, 63, 21, ''),
(157, 63, 22, ''),
(158, 64, 1, 'George Washington.....'),
(159, 64, 11, 'Tran Quoc Toan'),
(160, 64, 12, 'Kulottunga-I '),
(161, 64, 13, 'Marathas'),
(162, 64, 15, 'Babur '),
(163, 64, 16, 'Malabar'),
(164, 64, 17, 'Tharu'),
(165, 64, 18, 'Pali'),
(166, 64, 19, 'Mughal period'),
(167, 64, 20, 'Prakrit'),
(168, 64, 21, 'Haridwar district '),
(169, 64, 22, 'Industrialists'),
(170, 65, 1, 'George Washington.....'),
(171, 65, 11, 'Tran Quoc Toan'),
(172, 65, 12, 'Kulottunga-I '),
(173, 65, 13, 'Marathas'),
(174, 65, 15, 'Babur '),
(175, 65, 16, 'Malabar'),
(176, 65, 17, 'Tharu'),
(177, 65, 18, 'Pali'),
(178, 65, 19, 'Mughal period'),
(179, 65, 20, 'Kumaoni'),
(180, 65, 21, 'Haridwar district '),
(181, 65, 22, 'Landlords'),
(182, 67, 19, ''),
(183, 67, 22, ''),
(184, 67, 18, ''),
(185, 67, 11, ''),
(186, 67, 12, ''),
(187, 67, 15, ''),
(188, 67, 13, ''),
(189, 67, 17, ''),
(190, 67, 20, ''),
(191, 67, 16, ''),
(192, 68, 21, ''),
(193, 68, 19, ''),
(194, 68, 20, ''),
(195, 68, 18, ''),
(196, 68, 16, ''),
(197, 68, 17, ''),
(198, 68, 1, ''),
(199, 68, 12, ''),
(200, 68, 22, ''),
(201, 68, 15, ''),
(202, 69, 12, ''),
(203, 69, 17, ''),
(204, 69, 16, ''),
(205, 69, 19, ''),
(206, 69, 22, ''),
(207, 69, 15, ''),
(208, 69, 18, ''),
(209, 69, 21, ''),
(210, 69, 13, ''),
(211, 69, 20, '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `user_name` varchar(250) NOT NULL,
  `pass_word` varchar(250) NOT NULL,
  `full_name_user` varchar(250) NOT NULL,
  `role_id` int(11) NOT NULL,
  `enabled` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user_name`, `pass_word`, `full_name_user`, `role_id`, `enabled`) VALUES
(1, 'admin', '123', 'Nguyen Van Admin', 1, 1),
(3, 'hmtam', '123', 'Ho Minh Tam', 2, 1),
(4, 'user1', '123', 'Tran Van User1', 3, 1),
(5, 'user2', '123', 'Tran Van User2', 3, 1),
(8, 'dasdasd', '123', 'gfsgdf', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `role_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`id`, `role_name`) VALUES
(1, 'ROLE_ADMIN'),
(2, 'ROLE_DB'),
(3, 'ROLE_USER');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answer`
--
ALTER TABLE `answer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `quiz_id` (`quiz_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `exam_item`
--
ALTER TABLE `exam_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `exam_id` (`exam_id`,`quiz_id`),
  ADD KEY `quiz_id` (`quiz_id`);

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`,`exam_id`),
  ADD KEY `exam_id` (`exam_id`),
  ADD KEY `user_id_2` (`user_id`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`),
  ADD KEY `result_id` (`result_id`,`quiz_id`),
  ADD KEY `quiz_id` (`quiz_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answer`
--
ALTER TABLE `answer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=176;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `exam`
--
ALTER TABLE `exam`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `exam_item`
--
ALTER TABLE `exam_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;
--
-- AUTO_INCREMENT for table `quiz`
--
ALTER TABLE `quiz`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;
--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=212;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `answer`
--
ALTER TABLE `answer`
  ADD CONSTRAINT `answer_ibfk_1` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`id`);

--
-- Constraints for table `exam`
--
ALTER TABLE `exam`
  ADD CONSTRAINT `exam_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `category` (`id`);

--
-- Constraints for table `exam_item`
--
ALTER TABLE `exam_item`
  ADD CONSTRAINT `exam_item_ibfk_1` FOREIGN KEY (`exam_id`) REFERENCES `exam` (`id`),
  ADD CONSTRAINT `exam_item_ibfk_2` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`id`);

--
-- Constraints for table `quiz`
--
ALTER TABLE `quiz`
  ADD CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`);

--
-- Constraints for table `result`
--
ALTER TABLE `result`
  ADD CONSTRAINT `result_ibfk_2` FOREIGN KEY (`exam_id`) REFERENCES `exam` (`id`),
  ADD CONSTRAINT `result_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Constraints for table `review`
--
ALTER TABLE `review`
  ADD CONSTRAINT `review_ibfk_1` FOREIGN KEY (`result_id`) REFERENCES `result` (`id`),
  ADD CONSTRAINT `review_ibfk_2` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`id`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `user_role` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
