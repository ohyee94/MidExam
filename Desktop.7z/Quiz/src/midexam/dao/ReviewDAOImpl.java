package midexam.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.entities.Review;

@Repository(value="reviewDAO")
@Transactional
public class ReviewDAOImpl implements ReviewDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void Add(Review review) {
		sessionFactory.getCurrentSession().persist(review);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Review> findReviewByResultID(Integer id) {
		return sessionFactory.getCurrentSession().createSQLQuery("select * from midexam.review where result_id = :id").addEntity(Review.class).setParameter("id", id).list();
	}

}
