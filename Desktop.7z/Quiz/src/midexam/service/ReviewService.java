package midexam.service;

import java.util.List;

import midexam.entities.*;

public interface ReviewService {
	public void Add(Review review);
	public List<Review> findReviewByResultID(Integer id);
}
