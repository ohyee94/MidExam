package midexam.service;
import java.util.*;
import midexam.entities.*;

public interface QuizService {

	public List<Quiz> showAll();
	public void Add(Quiz quiz);
	public Quiz findQuiz(Integer id);
	public void Delete(Quiz quiz);
	public void Edit(Quiz quiz);
	public List<Quiz> findQuizByExamId(Integer id);
	public List<Quiz> findQuizByCourseId(Integer id);
	public List<Quiz> RandomQuiz(Integer id);

}
