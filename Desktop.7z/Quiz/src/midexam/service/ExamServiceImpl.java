package midexam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.dao.ExamDAO;
import midexam.entities.Exam;
import midexam.entities.ExamItem;
import midexam.entities.Quiz;

@Repository("ExamService")
@Transactional
public class ExamServiceImpl implements ExamService {

	@Autowired
	private ExamDAO examDAO;
	
	
	
	@Override
	public List<Exam> showAll() {
		
		return examDAO.showAll();
	}



	@Override
	public Exam findExamByID(Integer id) {
		
		return examDAO.findExamByID(id);
	}



	@Override
	public void Add(Exam exam) {
		examDAO.Add(exam);
		
	}



	@Override
	public void Edit(Exam exam) {
		examDAO.Edit(exam);
		
	}



	@Override
	public void Delete(Exam exam) {
		examDAO.Delete(exam);
	}



	@Override
	public void Insert(ExamItem examItem) {
		examDAO.Insert(examItem);
		
	}



	@Override
	public void Remove(ExamItem examItem) {
		examDAO.Remove(examItem);
		
	}



	@Override
	public ExamItem findExamItemByID(Integer Eid,Integer Qid) {
		
		return examDAO.findExamItemByID(Eid,Qid);
	}



	
}
