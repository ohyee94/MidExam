package midexam.service;

import java.util.*;
import midexam.entities.*;

public interface AnswerService {
		public List<Answer> findAnswerByQuizID(Integer id);
		public void Edit(Answer answer);
}
