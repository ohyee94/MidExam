package midexam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;

import midexam.dao.AnswerDAO;
import midexam.entities.Answer;

@Repository("AnswerService")
@Transactional
public class AnswerServiceImpl implements AnswerService{

	@Autowired
	private AnswerDAO answerDAO;
	
	@Override
	public List<Answer> findAnswerByQuizID(Integer id) {
		return answerDAO.findAnswerByQuizID(id);
	}

	@Override
	public void Edit(Answer answer) {
		answerDAO.Edit(answer);
	}

}
