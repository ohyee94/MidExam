package midexam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.dao.CategoryDAO;
import midexam.entities.Category;

@Repository("CategoryService")
@Transactional
public class CategoryServiceIpml implements CategoryService {
	@Autowired
	private CategoryDAO categoryDAO;

	@Override
	public List<Category> showAll() {

		return categoryDAO.showAll();
	}

}
