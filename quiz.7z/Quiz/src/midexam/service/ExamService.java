package midexam.service;



import midexam.entities.*;
import java.util.*;

public interface ExamService {

	public List<Exam> showAll();
}
