package midexam.service;

import java.util.*;
import midexam.entities.*;
public interface CategoryService {
	public List<Category> showAll();
}
