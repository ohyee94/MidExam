package midexam.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import midexam.entities.*;
import midexam.service.ExamService;
import midexam.service.QuizService;

@Controller
@RequestMapping(value = "/user**")
public class UserController {

	@Autowired
	private ExamService examService;
	
	@Autowired
	private QuizService quizService;

	@RequestMapping(method = RequestMethod.GET) public String welcome(ModelMap modelMap) {
		modelMap.addAttribute("message", "This is protected page - User Page!");
		return "user";
	}

	
	@RequestMapping(value="/choiceexam",method=RequestMethod.GET)
	public String choiceExam(ModelMap modelMap){
		modelMap.put("exams", examService.showAll());
		return "choiceExam";
	}
	
	@RequestMapping(value = "/startexam/{id}", method = RequestMethod.GET)
	public String start(@PathVariable(value = "id") Integer id,ModelMap modelMap) {
		 modelMap.put("quiz", quizService.findQuizByExamId(id));
		
		return "startExam";
	}
	
	@RequestMapping(value="/finishexam",method = RequestMethod.POST)
	public String finish(@ModelAttribute(value = "exam") @Valid Exam exam, 
			BindingResult bindingResult,ModelMap modelMap){
		
		
		return "resultExam";
	}
	


}