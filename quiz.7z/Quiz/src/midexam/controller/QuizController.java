package midexam.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import midexam.entities.Answer;
import midexam.entities.Quiz;
import midexam.service.AnswerService;
import midexam.service.CategoryService;
import midexam.service.QuizService;
import midexam.validator.QuizValidator;

@Controller
@RequestMapping(value = "/quiz**")
public class QuizController {

	@Autowired
	private QuizService quizService;
	
	@Autowired
	private AnswerService answerService;
	
	@Autowired
	private CategoryService categoryService;

	@RequestMapping(method = RequestMethod.GET)
	public String welcome(ModelMap modelMap) {
		modelMap.addAttribute("message", "This is protected page - DB Page!");
		return "database";
	}
	
	@RequestMapping(value="/listquiz",method = RequestMethod.GET)
	public String show(ModelMap modelMap) {
		modelMap.put("quizs", quizService.showAll());
		return "listQuiz";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		
		modelMap.put("quiz", new Quiz());
		modelMap.put("categorys",categoryService.showAll());
		return "addQuiz";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "quiz") @Valid Quiz quiz, BindingResult bindingResult) {
		QuizValidator quizValidator = new QuizValidator();
		quizValidator.validate(quiz, bindingResult);
		if (bindingResult.hasErrors()) {
			return "addQuiz";
		} else
			quizService.Add(quiz);
		return "redirect:/quiz/listquiz.html";
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable(value = "id") Integer id) {
		quizService.Delete(quizService.findQuiz(id));
		return "redirect:/quiz/listquiz.html";
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("quiz", quizService.findQuiz(id));
		modelMap.put("categorys", categoryService.showAll());
		modelMap.put("answers", answerService.findAnswerByQuizID(id));
//		System.out.println(answerService.findAnswerByQuizID(id).size());
		return "editQuiz";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "quiz") @Valid Quiz quiz,
			@ModelAttribute(value = "answer") @Valid Answer answer,
			BindingResult bindingResult,ModelMap modelMap) {
		QuizValidator quizValidator = new QuizValidator();
		quizValidator.validate(quiz, bindingResult);
		if (bindingResult.hasErrors()) {
			modelMap.put("categorys", categoryService.showAll());
			
			return "editQuiz";
		} else
//			quiz.getCategory();
//			quiz.getAnswers();
			quizService.Edit(quiz);
			answerService.Edit(answer);
		return "redirect:/quiz/listquiz.html";
	}
}
