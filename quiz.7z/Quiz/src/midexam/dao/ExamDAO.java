package midexam.dao;
import java.util.*;
import midexam.entities.*;
public interface ExamDAO {
	public List<Exam> showAll();
}
