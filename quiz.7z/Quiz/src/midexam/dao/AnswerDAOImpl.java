package midexam.dao;

import java.util.*;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.entities.*;


@Repository("AnswerDAO")
@Transactional
public class AnswerDAOImpl implements AnswerDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Answer> findAnswerByQuizID(Integer id) {
		
		return sessionFactory.getCurrentSession().createSQLQuery("select * from midexam.answer where quiz_id = :id").addEntity(Answer.class).setParameter("id", id).list();
	}

	@Override
	public void Edit(Answer answer) {
		
		sessionFactory.getCurrentSession().saveOrUpdate(answer);
	}

}
