package midexam.dao;

import java.util.*;
import midexam.entities.*;

public interface AnswerDAO {
	public List<Answer> findAnswerByQuizID(Integer id);
	public void Edit(Answer answer);
}
