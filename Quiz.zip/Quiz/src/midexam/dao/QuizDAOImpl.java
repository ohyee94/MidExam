package midexam.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.entities.ExamItem;
import midexam.entities.Quiz;

@Repository("QuizDAO")
@Transactional
public class QuizDAOImpl implements QuizDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Quiz> showAll() {
		
		return sessionFactory.getCurrentSession().createCriteria(Quiz.class).list();
	}

	@Override
	public void Add(Quiz quiz) {
		sessionFactory.getCurrentSession().persist(quiz);
		
	}

	@Override
	public Quiz findQuiz(Integer id) {
		return (Quiz) sessionFactory.getCurrentSession().get(Quiz.class, id);
	}

	@Override
	public void Delete(Quiz quiz) {
		
		sessionFactory.getCurrentSession().delete(quiz);
	}

	@Override
	public void Edit(Quiz quiz) {
		
		sessionFactory.getCurrentSession().saveOrUpdate(quiz);
	}

	

	
	@SuppressWarnings("unchecked")
	public List<Quiz> findQuizByExamId(Integer id){
		return sessionFactory.getCurrentSession().createSQLQuery("select * from midexam.exam_item where exam_id = :id").addEntity(ExamItem.class).setParameter("id", id).list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Quiz> findQuizByCourseId(Integer id) {
		
		return sessionFactory.getCurrentSession().createSQLQuery("select * from midexam.quiz where category_id = :id").addEntity(Quiz.class).setParameter("id", id).list();
	}
	
}

	
