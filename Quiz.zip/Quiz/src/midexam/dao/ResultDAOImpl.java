package midexam.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import midexam.entities.Result;
import midexam.entities.Review;

@Repository("ResultDAO")
@Transactional
public class ResultDAOImpl implements ResultDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Result> findResultByUserID(Integer id) {
		
		return sessionFactory.getCurrentSession().createSQLQuery("select * from midexam.result where user_id = :id").addEntity(Result.class).setParameter("id", id).list();

	}


	@Override
	public Review findReviewByResultID(Integer id) {
		
		return (Review) sessionFactory.getCurrentSession().createSQLQuery("select * from midexam.review where result_id = :id").addEntity(Review.class).setParameter("id", id).uniqueResult();
		
	}
	
	

	@Override
	public void Add(Result result) {
		sessionFactory.getCurrentSession().persist(result);
	}


	@Override
	public void Edit(Result result) {
		sessionFactory.getCurrentSession().saveOrUpdate(result);
		
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<Result> showAll() {
		
		return sessionFactory.getCurrentSession().createCriteria(Result.class).list();
	}
}
