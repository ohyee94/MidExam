package midexam.dao;

import java.util.*;
import midexam.entities.*;

public interface RoleDAO {
	public List<UserRole> showRole();
}
