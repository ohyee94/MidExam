package midexam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.dao.CategoryDAO;
import midexam.entities.Category;

@Repository("CategoryService")
@Transactional
public class CategoryServiceIpml implements CategoryService {
	@Autowired
	private CategoryDAO categoryDAO;

	@Override
	public List<Category> showAll() {

		return categoryDAO.showAll();
	}

	@Override
	public void Add(Category category) {
		categoryDAO.Add(category);
		
	}

	@Override
	public Category findCourse(Integer id) {
		
		return categoryDAO.findCourse(id);
	}

	@Override
	public void Delete(Category category) {
		categoryDAO.Delete(category);
		
	}

	@Override
	public void Edit(Category category) {
		categoryDAO.Edit(category);
		
	}

}
