package midexam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.dao.ReviewDAO;
import midexam.entities.Review;

@Repository(value="reviewService")
@Transactional
public class ReviewServiceImpl implements ReviewService{

	@Autowired
	private ReviewDAO reviewDAO;
	
	@Override
	public void Add(Review review) {
		reviewDAO.Add(review);
	}

	@Override
	public List<Review> findReviewByResultID(Integer id) {
		
		return reviewDAO.findReviewByResultID(id);
	}


}
