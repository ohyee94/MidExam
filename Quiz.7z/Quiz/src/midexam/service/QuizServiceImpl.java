package midexam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.dao.QuizDAO;
import midexam.entities.Quiz;

@Repository("QuizService")
@Transactional
public class QuizServiceImpl implements QuizService {

	@Autowired
	private QuizDAO quizDAO;

	@Override
	public List<Quiz> showAll() {
		return quizDAO.showAll();
	}

	@Override
	public void Add(Quiz quiz) {
		quizDAO.Add(quiz);

	}

	@Override
	public Quiz findQuiz(Integer id) {

		return quizDAO.findQuiz(id);
	}

	@Override
	public void Delete(Quiz quiz) {
		quizDAO.Delete(quiz);

	}

	@Override
	public void Edit(Quiz quiz) {
		quizDAO.Edit(quiz);

	}

	@Override
	public List<Quiz> findQuizByExamId(Integer id) {
		return quizDAO.findQuizByExamId(id);
	}

}
