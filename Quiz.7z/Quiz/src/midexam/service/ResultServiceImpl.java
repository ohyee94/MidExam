package midexam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.dao.ResultDAO;
import midexam.entities.Result;
import midexam.entities.Review;

@Repository("ResultService")
@Transactional
public class ResultServiceImpl implements ResultService{

	@Autowired
	private ResultDAO resultDAO;
	
	@Override
	public List<Result> findResultByUserID(Integer id) {
		return resultDAO.findResultByUserID(id);
	}

	@Override
	public Review findReviewByResultID(Integer id) {
		
		return resultDAO.findReviewByResultID(id);
	}

	@Override
	public void Add(Result result) {
		resultDAO.Add(result);
		
	}

	@Override
	public void Edit(Result result) {
		resultDAO.Edit(result);
		
	}

	@Override
	public List<Result> showAll() {
		
		return resultDAO.showAll();
	}

}
