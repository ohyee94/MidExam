package midexam.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import midexam.entities.*;
import midexam.service.RoleService;
import midexam.service.UserService;
import midexam.validator.UserValidator;

@Controller
@RequestMapping(value = "/admin**")
public class AdminController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private RoleService roleSerive;

	@RequestMapping(method = RequestMethod.GET)
	public String welcome(ModelMap modelMap) {
		modelMap.addAttribute("message", "This is protected page - Admin Page!");
		return "admin";
	}

	@RequestMapping(value = "/listUser", method = RequestMethod.GET)
	public String listuser(ModelMap modelMap) {
		modelMap.put("listusers", userService.showAll());
		return "listUser";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {
		
		modelMap.put("user", new User());
		modelMap.put("roles", roleSerive.showRole());
		return "addUser";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "user") @Valid User user, 
			BindingResult bindingResult,
			ModelMap modelMap) {
		
		UserValidator userValidator = new UserValidator();
		userValidator.validate(user, bindingResult);
		
		if (bindingResult.hasErrors()) {
			modelMap.put("user", new User());
			modelMap.put("roles", roleSerive.showRole());
			return "addUser";
		} else
			userService.Add(user);
		return "redirect:/admin/listUser.html";
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable(value = "id") Integer id) {
		userService.Delete(userService.findUser(id));
		return "redirect:/admin/listUser.html";
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("user", userService.findUser(id));

		return "editUser";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "user") @Valid User user, BindingResult bindingResult) {
		UserValidator userValidator = new UserValidator();
		userValidator.validate(user, bindingResult);
		if (bindingResult.hasErrors()) {
			return "editUser";
		} else
			userService.Edit(user);
		return "redirect:/admin/listUser.html";
	}
}