package midexam.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import midexam.entities.*;
import midexam.service.AnswerService;
import midexam.service.ExamService;
import midexam.service.QuizService;
import midexam.service.ResultService;
import midexam.service.ReviewService;
import midexam.service.UserService;

@Controller
@RequestMapping(value = "/user**")
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private ExamService examService;

	@Autowired
	private QuizService quizService;

	@Autowired
	private ResultService resultService;

	@Autowired
	private ReviewService reviewService;

	@Autowired
	private AnswerService answerService;

	@RequestMapping(method = RequestMethod.GET)
	public String welcome(ModelMap modelMap) {
		modelMap.addAttribute("message", "This is protected page - User Page!");
		return "user";
	}

	/* List ResultExam */
	@RequestMapping(value = "/listre", method = RequestMethod.GET)
	public String listResult(ModelMap modelMap) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (!(auth instanceof AnonymousAuthenticationToken)) {
			UserDetails userDetails = (UserDetails) auth.getPrincipal();
			modelMap.put("username", userDetails.getUsername());
			User user = userService.findUserByUsername(userDetails.getUsername());
			if (user.getUserRole().getId() == 1) {
				modelMap.put("results", resultService.showAll());
			} else {
				modelMap.put("userID", user.getId());
				modelMap.put("results", resultService.findResultByUserID(user.getId()));
			}
		}

		return "listResultExam";
	}

	/* Reivew Result */
	@RequestMapping(value = "/review/{id}", method = RequestMethod.GET)
	public String review(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("review", reviewService.findReviewByResultID(id));
		return "reviewExam";
	}

	/* Choice Exam */
	@RequestMapping(value = "/choiceexam", method = RequestMethod.GET)
	public String choiceExam(ModelMap modelMap) {
		modelMap.put("exams", examService.showAll());
		return "choiceExam";
	}

	/* Doing Exam */
	@RequestMapping(value = "/startexam/{id}", method = RequestMethod.GET)
	public String doExam(@PathVariable(value = "id") Integer id, ModelMap modelMap) {

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetails = (UserDetails) auth.getPrincipal();
		modelMap.put("examID", id);
		modelMap.put("exam", quizService.findQuizByExamId(id));
		modelMap.put("number", quizService.findQuizByExamId(id).size());
		return "startExam";
	}

	/* Return Result Exam - Finish Exam */
	@RequestMapping(value = "/finishexam", method = RequestMethod.POST)
	public String doExam(@RequestParam(value = "examID") Integer examID, @RequestParam(value = "number") Integer number,
			// @RequestParam(value="exam") Exam exam,
			HttpServletRequest request, ModelMap modelMap) {
		Integer questionid;
		Integer answerid;
		Integer point = 0;
		Integer trueAns;
		Integer numTrueChoice = 0;
		// System.out.println( "===========");
		// System.out.println(examID);
		// System.out.println(number);

		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetails = (UserDetails) auth.getPrincipal();

		// Add Result
		Result result = new Result();

		result.setUser(userService.findUserByUsername(userDetails.getUsername()));
		result.setExam(examService.findExamByID(examID));
		// result.setPoint(0);
		result.setPassOrFail("");
		resultService.Add(result);

		// Add Reivew And Update Result
		for (int i = 0; i < number; i++) {

			questionid = Integer.parseInt(request.getParameter("quizid_" + i));
			if (request.getParameter("answerid_" + i) == null) {
				answerid = 0;
			} else {
				answerid = Integer.parseInt(request.getParameter("answerid_" + i));
			}
			trueAns = answerService.findTrueAnswerByQuizID(questionid).getId();
			if (answerid == trueAns) {
				numTrueChoice++;
				point++;
			}
			Review review = new Review();
			if (answerid == 0) {
				review.setChoiceAnswer("");
			} else {
				review.setChoiceAnswer(answerService.findAnswer(answerid).getContent());
			}
			
			review.setQuiz(quizService.findQuiz(questionid));
			review.setResult(result);
			reviewService.Add(review);

		}
		if (((double) (numTrueChoice / number)) >= 0.7) {
			result.setPassOrFail("Pass");
		} else {
			result.setPassOrFail("Fail");
		}
		result.setPoint(point);

		resultService.Edit(result);
		modelMap.put("review", reviewService.findReviewByResultID(result.getId()));

		return "reviewExam";
		// return "redirect:/user/listre.html";
	}

}