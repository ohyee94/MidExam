package midexam.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import midexam.entities.Quiz;
import midexam.service.QuizService;
import midexam.validator.QuizValidator;

@Controller
@RequestMapping(value = "/quiz**")
public class QuizController {

	@Autowired
	private QuizService quizService;

	@RequestMapping(method = RequestMethod.GET)
	public String show(ModelMap modelMap) {
		modelMap.put("quizs", quizService.showAll());
		// modelMap.put("answers", answerService.findAnswerByIdQuestion(id));
		return "listQuiz";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add(ModelMap modelMap) {

		modelMap.put("quiz", new Quiz());
		return "addQuiz";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@ModelAttribute(value = "quiz") @Valid Quiz quiz, BindingResult bindingResult) {
		QuizValidator quizValidator = new QuizValidator();
		quizValidator.validate(quiz, bindingResult);
		if (bindingResult.hasErrors()) {
			return "addQuiz";
		} else
			quizService.Add(quiz);
		return "redirect:/quiz.html";
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public String delete(@PathVariable(value = "id") Integer id) {
		quizService.Delete(quizService.findQuiz(id));
		return "redirect:/quiz.html";
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public String edit(@PathVariable(value = "id") Integer id, ModelMap modelMap) {
		modelMap.put("quiz", quizService.findQuiz(id));

		return "editQuiz";
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST)
	public String edit(@ModelAttribute(value = "quiz") @Valid Quiz quiz, BindingResult bindingResult) {
		QuizValidator quizValidator = new QuizValidator();
		quizValidator.validate(quiz, bindingResult);
		if (bindingResult.hasErrors()) {
			return "editQuiz";
		} else
			quizService.Edit(quiz);
		return "redirect:/quiz.html";
	}
}
