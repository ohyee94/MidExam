package midexam.dao;
import midexam.entities.*;
import java.util.*;
public interface CategoryDAO {
	public List<Category> showAll();
}
