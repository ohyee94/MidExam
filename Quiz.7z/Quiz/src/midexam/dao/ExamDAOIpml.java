package midexam.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import midexam.entities.Exam;

@Repository("ExamDAO")
@Transactional
public class ExamDAOIpml implements ExamDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Exam> showAll() {
		
		return sessionFactory.getCurrentSession().createCriteria(Exam.class).list(); 
	}

}
