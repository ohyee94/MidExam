package midexam.dao;

import java.util.*;
import midexam.entities.*;

public interface AnswerDAO {
	public List<Answer> findAnswerByQuizID(Integer id);
	public Answer findAnswer(Integer id);
	public void Add(Answer answer);
	public void Delete(Answer answer);
	public void Edit(Answer answer);
}
